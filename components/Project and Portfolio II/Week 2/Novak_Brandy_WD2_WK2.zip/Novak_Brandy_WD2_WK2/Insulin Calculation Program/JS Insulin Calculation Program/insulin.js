var glucose = 175;
document.write("With a blood glucose level of " + glucose);

if(glucose >= 71){
document.write(" you will need to take 10 units of insulin.");
}
         
else if(glucose >= 151){
document.write(" you will need to take 12 units of insulin.");
}
         
else if(glucose >= 201){
document.write(" you will need to take 14 units of insulin.");
}

else if(glucose >= 251){
document.write(" you will need to take 16 units of insulin.");
}

else if(glucose >= 301){
document.write(" you will need to take 18 units of insulin.");
}

else if(glucose >= 351){
document.write(" you will need to take 20 units of insulin.");
}

else{
document.write("<b> your physician will advise you on how much insulin to take.</b>");
}