﻿using System;

namespace Novak_Brandy_Conditionals_Assignment
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			/*
			 * Brandy Novak
			 * SDI Section 01
			 * Conditionals Assignment
			 * January 20, 2016
			*/

			//Introduction statement and explanation of the program using concatenation.
			string programWelcome = "Welcome to the Insulin Calculation Program!\r\n";
			programWelcome += "This program determines the total amount of insulin that is needed based on your blood glucose level. \r\n Please enter the following information, followed by the enter key to submit the data into the program.";
			Console.WriteLine (programWelcome);

			//Asking the user to enter the brand of insulin that they use.
			Console.WriteLine ("To begin, please enter your brand of insulin:");
				 
			//Waiting for the user to input the name brand of their insulin.
			string insulinNameString = Console.ReadLine ();
					 
			//Asking the user to enter their base insulin amount.
			Console.WriteLine ("Now, please enter the base amount of insulin that you use:");
					 
			//Waiting for the user to input their base insulin amount.
			string insulinBaseString = Console.ReadLine ();

			//Converting the user entered string - insulinBaseString - to an int number type.
			int insulinBase = int.Parse (insulinBaseString);
					 
			//Asking the user to enter their blood glucose number.
			Console.WriteLine ("Finally, please enter your blood glucose number:");
						 
			//Waiting for the user to input their blood glucose number.
			string glucoseNumberString = Console.ReadLine ();
						 
			//Converting the user entered string - glucoseNumberString - to an int number type.
			int glucoseNumber = int.Parse (glucoseNumberString);

			//Conditional else if statements and logic operators that determine the slidding scale number based on the user inputed data and informs the user.
			if (glucoseNumber > 71 && glucoseNumber < 150) {
				Console.WriteLine ("Based on this information, the slidding scale correction number is 0.");
			} else if (glucoseNumber > 151 && glucoseNumber < 200) {
				Console.WriteLine ("Based on this information, the slidding scale correction number is 2.");
			} else if (glucoseNumber > 201 && glucoseNumber < 250) {
				Console.WriteLine ("Based on this information, the slidding scale correction number is 4.");
			} else if (glucoseNumber > 251 && glucoseNumber < 300) {
				Console.WriteLine ("Based on this information, the slidding scale correction number is 6.");
			} else if (glucoseNumber > 301 && glucoseNumber < 350) {
				Console.WriteLine ("Based on this information, the slidding scale correction number is 8.");
			} else if (glucoseNumber > 351 && glucoseNumber < 400) {
				Console.WriteLine ("Based on this information, the slidding scale correction number is 10.");
			} else
				Console.WriteLine ("Based on this information, please contact your physician.");

			//Conditional else if statements and logic operators that calculate the total number of insulin units needed based on the user inputed data and informs the user.
			if (glucoseNumber > 71 && glucoseNumber < 150) {
				int totalInsulin = insulinBase + 0;
				Console.WriteLine ("You will need to take a total of " +totalInsulin+ " units of " +insulinNameString+ " insulin.");
			} else if (glucoseNumber > 151 && glucoseNumber < 200) {
				int totalInsulin = insulinBase + 2;
				Console.WriteLine ("You will need to take a total of " +totalInsulin+ " units of " +insulinNameString+ " insulin.");
			} else if (glucoseNumber > 201 && glucoseNumber < 250) {
				int totalInsulin = insulinBase + 4;
				Console.WriteLine ("You will need to take a total of " +totalInsulin+ " units of " +insulinNameString+ " insulin.");
			} else if (glucoseNumber > 251 && glucoseNumber < 300) {
				int totalInsulin = insulinBase + 6;
				Console.WriteLine ("You will need to take a total of " +totalInsulin+ " units of " +insulinNameString+ " insulin.");
			} else if (glucoseNumber > 301 && glucoseNumber < 350) {
				int totalInsulin = insulinBase + 8;
				Console.WriteLine ("You will need to take a total of " +totalInsulin+ " units of " +insulinNameString+ " insulin.");
			} else if (glucoseNumber > 351 && glucoseNumber < 400) {
				int totalInsulin = insulinBase + 10;
				Console.WriteLine ("You will need to take a total of " +totalInsulin+ " units of " +insulinNameString+ " insulin.");
			} else
				Console.WriteLine ("Your physician will advise you on how much " +insulinNameString+ " insulin you need to take due to your high blood glucose number.");

			/* 
			 * To test data: I entered the insulin Humalog, 10 base units of insulin, and the blood glucose number 256. 
			 * The program gave me the following results: a slidding scale corection number of 6 and a total insulin number of 16.
			*/
		}
	}
}
