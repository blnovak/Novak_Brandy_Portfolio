﻿using System;

namespace Novak_Brandy_Functions_Assignment
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			/*
			 * Brandy Novak
			 * SDI Section 01
			 * January 27, 2016
			 * Functions Assignment
			*/

			//Introduction statement and explanation of the program.
			Console.WriteLine ("Welcome To The Lunch Calculation Program.\r\nThis program determines how much you spend on lunch in a week and the daily average.\r\nPlease enter the required data and press the enter key.");

			//Asking the user to enter the monday lunch value.
			Console.WriteLine ("Please enter the amount you spend on lunch on Monday:");

			//Waiting for the user to input the monday lunch value.
			string monLunchAmountString = Console.ReadLine ();

			//Validating that the user entered response is not blank.
			while (string.IsNullOrWhiteSpace(monLunchAmountString)) {

				//Advising the user that they entered an invalid value.
				Console.WriteLine ("The submitted response is blank.\r\nPlease re-submit the information.");

				//Redefining the variable.
				monLunchAmountString = Console.ReadLine ();
			}

			//Converting the user entered string - monLunchAmountString - to a double number type.
			double monLunchAmount = double.Parse (monLunchAmountString);

			//Asking the user to enter the tuesday lunch value.
			Console.WriteLine ("Please enter the amount you spend on lunch on Tuesday:");

			//Waiting for the user to input the tuesday lunch value.
			string tueLunchAmountString = Console.ReadLine ();

			//Validating that the user entered response is not blank.
			while (string.IsNullOrWhiteSpace (tueLunchAmountString)) {
				
				//Advising the user that they entered an invalid value.
				Console.WriteLine ("The submitted response is blank.\r\nPlease re-submit the information.");

				//Redefining the variable.
				tueLunchAmountString = Console.ReadLine ();
			}

			//Converting the user entered string - tueLunchAmountString - to a double number type.
			double tueLunchAmount = double.Parse (tueLunchAmountString);

			//Asking the user to enter the wednesday lunch value.
			Console.WriteLine ("Please enter the amount you spend on lunch on Wednesday:");

			//Waiting for the user to input the wednesday lunch value.
			string wedLunchAmountString = Console.ReadLine ();

			//Validating that the user entered response is not blank.
			while (string.IsNullOrWhiteSpace (tueLunchAmountString)) {
				
				//Advising the user that they entered an invalid value.
				Console.WriteLine ("The submitted response is blank.\r\nPlease re-submit the information.");

				//Redefining the variable.
				wedLunchAmountString = Console.ReadLine ();
			}

			//Converting the user entered string - wedLunchAmountString - to a double number type.
			double wedLunchAmount = double.Parse (wedLunchAmountString);

			//Asking the user to enter the thursday lunch value.
			Console.WriteLine ("Please enter the amount you spend on lunch on Thursday:");

			//Waiting for the user to input the thursday lunch value.
			string thursLunchAmountString = Console.ReadLine ();

			//Validating that the user entered response is not blank.
			while (string.IsNullOrWhiteSpace (thursLunchAmountString)) {
				
				//Advising the user that they entered an invalid value.
				Console.WriteLine ("The submitted response is blank.\r\nPlease re-submit the information.");

				//Redefining the variable.
				thursLunchAmountString = Console.ReadLine ();
			}

			//Converting the user entered string - thursLunchAmountString - to a double number type.
			double thursLunchAmount = double.Parse (thursLunchAmountString);

			//Asking the user to enter the friday lunch value.
			Console.WriteLine ("Please enter the amount you spend on lunch on Friday:");

			//Waiting for the user to input the friday lunch value.
			string friLunchAmountString = Console.ReadLine ();

			//Validating that the user entered response is not blank.
			while (string.IsNullOrWhiteSpace (friLunchAmountString)) {
				
				//Advising the user that they entered an invalid value.
				Console.WriteLine ("The submitted response is blank.\r\nPlease re-submit the information.");

				//Redefining the variable.
				friLunchAmountString = Console.ReadLine ();
			}

			//Converting the user entered string - friLunchAmountString - to a double number type.
			double friLunchAmount = double.Parse (friLunchAmountString);

			//Array storing the lunch values for each day of the week - monday, tuesday, wednesday, thursday, and friday - entered by the user.
			double[] lunchValues = new double[5]{monLunchAmount, tueLunchAmount, wedLunchAmount, thursLunchAmount, friLunchAmount};

			//Declaring and assigning a 0 value for the totalLunchSum variable.
			double totalLunchSum = 0;

			//Declaring and assigning a 0 value for the aveLunchSum variable.
			double aveLunchSum = 0;

			//foreach loop to calculate the weekly sum and daily average for the user entered data.
			foreach (double lunchArrayItem in lunchValues) {

				//Formula to calculate the total sum spent on lunch in a week.
				totalLunchSum = totalLunchSum + lunchArrayItem;

				//Formula to calculate the daily amount spent on lunch.
				aveLunchSum = totalLunchSum / 5;
			}
			//Conclusion statement showing the total amount spent on lunch in a week.
			Console.WriteLine ("You spend a total of ${0} on lunch a week.", totalLunchSum);

			//Conclusion statement showing the daily amount spent on lunch.
			Console.WriteLine ("On average you spend ${0} a day on lunch.", aveLunchSum);

			/*
			 * To test the data: I entered the values: 5.01, 2.99, 16.23, 4.37, and 14.82.
			 * The program gave me the following results: 43.42 for the total amount and 8.684 for the daily amount.
			 */

		}
	}
}
