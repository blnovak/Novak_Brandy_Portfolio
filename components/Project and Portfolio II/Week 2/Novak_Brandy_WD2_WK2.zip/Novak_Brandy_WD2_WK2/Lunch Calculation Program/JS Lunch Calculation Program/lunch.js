// variable declaration
var lunchAmount = [8.23, 10.05, 26.01, 2.06, 3.27, 0.00, 9.99];
var total = 0;

for(var item in lunchAmount){
total = total + lunchAmount[item];
ave = total / 7;
}

// displays the weekly sum spent on lunch
document.write("You spent $" + total + " on lunch in one week." + "<br>");
document.write("On average you spend $" + ave + " a day on lunch.");