﻿using System;

namespace Novak_Brandy_Functions_Assignment
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			/*
			 * Brandy Novak
			 * SDI Section 01
			 * January 30, 2016
			 * Functions Assignment
			*/

			//Introduction to the program.
			Console.WriteLine ("Welcome To The Hours Worked Calculation Program.");

			//Explanation of the program.
			Console.WriteLine ("This program determines how many hours you work approximately in a week, a month, and in a year.");

			//Explanation to the user on how to submit the data.
			Console.WriteLine ("Enter the required information and press the enter key.");

			//Asking the user to enter the amount of hours worked each day.
			Console.WriteLine ("Please enter the amount of hours you work each day:");

			//Waiting for the user to input the amount of hours value.
			string hoursWorkedString = Console.ReadLine ();

			//Declaration of the hoursWorked variable to hold the converted value.
			double hoursWorked;

			//Validating that the user is entering a valid data value using a while loop.
			while (!double.TryParse(hoursWorkedString, out hoursWorked)) {

				//Advising the user that they entered an invalid value.
				Console.WriteLine ("You submitted an invalid response.\r\nPlease re-submit the information as a number and do not leave blank.");

				//Asking the user to enter the amount of hours worked each day.
				Console.WriteLine ("Please enter the amount of hours you work each day:");

				//Redefining the user entered variable.
				hoursWorkedString = Console.ReadLine ();
			}

			//Asking the user to enter the amount of days they work in a week.
			Console.WriteLine ("Please enter the amount of days you work in a week:");

			//Waiting for the user to input the amount of days value.
			string daysPerWeekString = Console.ReadLine ();

			//Declaration of the daysPerWeek variable to hold the converted value.
			double daysPerWeek;

			//Validating that the user is entering a valid data value using a while loop.
			while (!double.TryParse(daysPerWeekString, out daysPerWeek)) {

				//Advising the user that they entered an invalid value.
				Console.WriteLine ("You submitted an invalid response.\r\nPlease re-submit the information as a number and do not leave blank.");

				//Asking the user to enter the amount of days they work in a week.
				Console.WriteLine ("Please enter the amount of days you work in a week:");

				//Redefining the user entered variable.
				daysPerWeekString = Console.ReadLine ();
			}

			//Asking the user to enter the amount of weeks they work in a month.
			Console.WriteLine ("Please enter the amount of weeks you work in a month:");

			//Waiting for the user to input the amount of weeks value.
			string weeksPerMonthString = Console.ReadLine ();

			//Declaration of variable to hold the converted value.
			double weeksPerMonth;

			//Validating that the user is entering a valid data value using a while loop.
			while (!double.TryParse(weeksPerMonthString, out weeksPerMonth)) {

				//Advising the user that they entered an invalid value.
				Console.WriteLine ("You submitted an invalid response.\r\nPlease re-submit the information as a number and do not leave blank.");

				//Asking the user to enter the amount of weeks they work in a month.
				Console.WriteLine ("Please enter the amount of weeks you work in a month:");

				//Redefining the user entered variable.
				weeksPerMonthString = Console.ReadLine ();
			}

			//Asking the user to enter the amount of months they work in a year.
			Console.WriteLine ("Please enter the amount of months you work in a year:");

			//Waiting for the user to input the amount of months value.
			string monthsPerYearString = Console.ReadLine ();

			//Declaration of the monthsPerYear variable to hold the converted value.
			double monthsPerYear;

			//Validating that the user is entering a valid data value using a while loop.
			while (!double.TryParse(monthsPerYearString, out monthsPerYear)) {

				//Advising the user that they entered an invalid value.
				Console.WriteLine ("You submitted an invalid response.\r\nPlease re-submit the information as a number and do not leave blank.");

				//Asking the user to enter the amount of months they work in a year.
				Console.WriteLine ("Please enter the amount of months you work in a year:");

				//Redefining the user entered variable.
				monthsPerYearString = Console.ReadLine ();
			}

			//Creation of function that calls the weekCalc method.
			double week = weekCalc(hoursWorked, daysPerWeek);

			//Informing the user of the hours worked in a week.
			Console.WriteLine("You work approximately {0} hours in a week.", week);

			//Creation of function that calls the monthCalc method.
			double month = monthCalc(hoursWorked, daysPerWeek, weeksPerMonth);

			//Informing the user of the hours worked in a month.
			Console.WriteLine("You work approximately {0} hours in a month.", month);

			//Creation of function that calls the yearCalc method.
			double year = yearCalc(hoursWorked, daysPerWeek, weeksPerMonth, monthsPerYear);

			//Informing the user of the hours worked in a year.
			Console.WriteLine("You work approximately {0} hours in a year.", year);

			/* 
			 * The data entered: 8 hours a day, 5 days a week, 4 weeks a month, and 12 months a year.
			 * The program calculated: 40 hours a week, 160 hours a month, and 1920 hours a year.
			*/
		}

		//Creation of a function that determines the amount of hours worked in a week.
		public static double weekCalc(double hours, double days){

			//Calculation of hours worked in a week and creation of a variable.
			double week = hours * days;

			//Return the value of the hours worked in a week.
			return week;
		}

		//Creation of a function that determines the amount of hours worked in a month.
		public static double monthCalc(double hours, double days, double weeks){

			//Calculation of the hours worked in a month and creation of a variable.
			double month = hours * days * weeks;

			//Return the value of the hours worked in a month.
			return month;
		}

		//Creation of a function  that determines the amount of hours worked in a year.
		public static double yearCalc(double h, double d, double w, double m){

			//Calculation of the hours worked in a year and creation of a variable.
			double year = h * d * w * m;

			//Return the value of the hours worked in a year.
			return year;
		}
	}
}
