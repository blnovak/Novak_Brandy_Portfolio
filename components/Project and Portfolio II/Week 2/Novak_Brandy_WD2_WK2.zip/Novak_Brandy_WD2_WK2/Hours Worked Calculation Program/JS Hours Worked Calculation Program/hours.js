// function that calculates the hours worked per day
function hoursPerDay(){
var day = 8;
return day;
}

// displays the hours worked per day to the user
document.write("Hours worked per day: " + hoursPerDay() + "<br>");

// function that calculates the hours worked per week
function hoursPerWeek(){
var week = 8 * 5;
return week;
}

//displays the hours worked per week to the user
document.write("Hours worked per week: " + hoursPerWeek() + "<br>");

// function that calculates the hours worked per month
function hoursPerMonth(){
var month = 8 * 5 * 4;
return month;
}

//displays the hours worked per month to the user
document.write("Hours worked per month: " + hoursPerMonth() + "<br>");

// function that calculates the hours worked per year
function hoursPerYear(){
var year = 8 * 5 * 4 * 12;
return year;

}

// displays the hours worked per year to the user
document.write("Hours worked per year: " + hoursPerYear() + "<br>");