﻿using System;

namespace Novak_Brandy_Expressions_Assignment
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			/* 
			 * Brandy Novak
			 * SDI Section 01
			 * Expressions Assignment
			 * January 13, 2016
			 */

			//Introduction statement and explanation of the program using the addition assignment operator (+=) to concatenate the string text.
			string introWelcome = "Welcome To The Case Ticket Productivity Program!\r\n";
			introWelcome += "To get started please enter the following information, followed by the enter key to submit the data.";
			Console.WriteLine(introWelcome);

			//Asking the user to enter how many hours they work in a week.
			Console.WriteLine("First, please enter how many hours you work in one week:");

			//Waiting for the user to input the amount of hours they work in a week.
			string hoursPerWeekString = Console.ReadLine();

			//Converting the user entered string - hoursPerWeekString - to a double number type.
			double hoursPerWeek = double.Parse(hoursPerWeekString);

			//Asking the user to enter how many days they work in a week.
			Console.WriteLine("Next, please enter how many days you work in one week:");

			//Waiting for the user to input the amount of days they work in a week.
			string daysPerWeekString = Console.ReadLine();

			//Converting the user entered string - daysPerWeekString - to a double number type.
			double daysPerWeek = double.Parse(daysPerWeekString);

			//Asking the user to enter how many cases they complete in a week.
			Console.WriteLine("Finally, please enter how many case tickets you complete within one week:");

			//Waiting for the user to input the number of cases they complete in a week.
			string casesPerWeekString = Console.ReadLine();

			//Converting the user entered string - casesPerWeekString - to a double number type.
			double casesPerWeek = double.Parse(casesPerWeekString);

			//Formula to calculate the number of cases completed per hour.
			double casesPerHour = casesPerWeek / hoursPerWeek;

			//Formula to calculate the number of hours worked per day in one work week.
			double hoursPerDay = hoursPerWeek / daysPerWeek;

			//Formula to calculate the number of cases completed per day.
			double casesPerDay = casesPerHour * hoursPerDay;

			//An array storing the amount of days in a month and in a year that is to be used in the formula calculation of the amount of case tickets completed within a month and year.
			int[] dayAmount = new int[5];
			dayAmount [0] = 31;
			dayAmount [1] = 30;
			dayAmount [2] = 29;
			dayAmount [3] = 28;
			dayAmount [4] = 365;

			//Formula to calculate the number of cases completed within a month days using an array and the previous casesPerDay formula.
			double casesPerMonth = casesPerDay * dayAmount[1];

			//Formula to calculate the number of case tickets completed within a year using an array and the previous casesPerDay formula.
			double casesPerYear = casesPerDay * dayAmount[4];

			//Conclusion statement showing the calculated results of the amount of case tickets worked per hour and per day, based on the information entered by the user.
			Console.WriteLine("Based on the submitted responses:\r\nYou complete approximately " +casesPerHour+ " case tickets per hour and " +casesPerDay+ " case tickets per day.");

			//Conclusion statement showing the calculated results of the amount of case tickets worked per 30 days and 365 days, based on the information entered by the user.
			Console.WriteLine("In " +dayAmount[1]+ " days you would complete approximately " +casesPerMonth+ " case tickets and in " +dayAmount[4]+ " days you would complete approximately " +casesPerYear+ " case tickets.");

			/* 
			 * To test data: I entered 40 hours per week, 5 days per week, and 15 case tickets completed in a week.
			 * The program gave me the following results: 0.375 case tickets per hour, 3 case tickets per day, 90 cases within 30 days, and 1095 case tickets within 365 days.
			*/
		}
	}
}
