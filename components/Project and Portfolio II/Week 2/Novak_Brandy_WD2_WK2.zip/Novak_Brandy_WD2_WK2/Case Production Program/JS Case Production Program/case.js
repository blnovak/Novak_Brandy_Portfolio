// variable declaration
var hoursPerWeek = 40;
var daysPerWeek = 5;
var casesPerWeek = 25;

// formula that calculates the number of cases per hour
var casesPerHour = casesPerWeek / hoursPerWeek;

// formula that calculates the number of hours worked per day in 1 work week
var hoursPerDay = hoursPerWeek / daysPerWeek;

// formula that calculates the number of cases completed per day
var casesPerDay = casesPerHour * hoursPerDay;

// function that determines the number of cases completed within a month using an array
function casesPerMonth() {
var casesMonth = casesPerDay * 30;
return casesMonth;
}

// function that determines the number of cases completed within a year using an array
function casesPerYear() {
var casesYear = casesPerDay * 365;
return casesYear;
}

// displays the case productivity to the user
document.write("Cases Completed Per Hour: " + casesPerHour + "<br>");
document.write("Cases Completed Per Day: " + casesPerDay + "<br>");
document.write("Cases Completed Per Week: " + casesPerWeek + "<br>");
document.write("Cases Completed Per Month: " + casesPerMonth() + "<br>");
document.write("Cases Completed Per Year: " + casesPerYear() + "<br>");