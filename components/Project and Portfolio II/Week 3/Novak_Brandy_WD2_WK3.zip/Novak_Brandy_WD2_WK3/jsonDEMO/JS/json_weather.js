// JSON weather information

var results = '{"forecast" : [' +
	'{"day":"Fri", "high":"80", "low":"62", "text":"Sunny"},' + 
	'{"day":"Sat", "high":"82", "low":"63", "text":"Partly Cloudy"},' +  	'("day":"Sun", "high":"85", "low":"65", "text":"Partly Cloudy"}]}';

// JSON object date

var jsonObj = {"data":[
    {"day”:"Fri", "date":"17 Oct 2014"},
    {"day”:"Sat", "date":"18 Oct 2014"},
    {"day":"Sun", "date":"9 Oct 2014"}
]} 